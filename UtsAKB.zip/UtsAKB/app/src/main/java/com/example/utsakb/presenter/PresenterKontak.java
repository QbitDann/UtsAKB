package com.example.utsakb.presenter;

public class PresenterKontak {
}
